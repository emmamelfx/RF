/**
 * DESIGN: Wellness Report — Earthy Editorial
 * Color: Warm cream bg, forest green primary, amber gold accent
 * Fonts: Cormorant Garamond (display), DM Sans (body), DM Mono (data)
 * Layout: Editorial magazine, scroll-driven reveal, asymmetric sections
 */

import { useEffect, useRef, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  AreaChart,
  Area,
  Legend,
} from "recharts";

// ─── Data ────────────────────────────────────────────────────────────────────

const contentFormats = [
  { name: "Imagen Estática", value: 35.8, color: "#1B4332" },
  { name: "UGC / Testimonial", value: 32.6, color: "#40916C" },
  { name: "Video Profesional", value: 21.0, color: "#D4A017" },
  { name: "Animación", value: 8.4, color: "#8B5E3C" },
  { name: "Carrusel", value: 2.2, color: "#C8A96E" },
];

const contentTypes = [
  { name: "Demo de Producto", value: 44.2 },
  { name: "Prueba Social", value: 17.4 },
  { name: "Lifestyle", value: 13.0 },
  { name: "Oferta/Descuento", value: 11.6 },
  { name: "Educativo", value: 11.0 },
  { name: "Antes/Después", value: 1.2 },
  { name: "Meme", value: 1.0 },
];

const engagementData = [
  { metric: "CTR Industria Salud", benchmark: 1.63, topPerformers: 3.5 },
  { metric: "Engagement IG (Wellness)", benchmark: 3.1, topPerformers: 6.5 },
  { metric: "Engagement FB", benchmark: 1.0, topPerformers: 2.5 },
  { metric: "Micro-Influencers", benchmark: 3.86, topPerformers: 6.8 },
  { metric: "Mega-Influencers", benchmark: 1.21, topPerformers: 2.8 },
];

const postingHours = [
  { hour: "6am", lun: 1, mar: 1, mie: 1, jue: 1, vie: 1 },
  { hour: "7am", lun: 2, mar: 2, mie: 2, jue: 2, vie: 2 },
  { hour: "8am", lun: 3, mar: 3, mie: 3, jue: 3, vie: 3 },
  { hour: "9am", lun: 4, mar: 4, mie: 4, jue: 4, vie: 4 },
  { hour: "10am", lun: 5, mar: 5, mie: 5, jue: 5, vie: 5 },
  { hour: "11am", lun: 6, mar: 8, mie: 8, jue: 7, vie: 6 },
  { hour: "12pm", lun: 7, mar: 9, mie: 9, jue: 8, vie: 7 },
  { hour: "1pm", lun: 8, mar: 10, mie: 10, jue: 9, vie: 7 },
  { hour: "2pm", lun: 7, mar: 9, mie: 9, jue: 8, vie: 6 },
  { hour: "3pm", lun: 6, mar: 8, mie: 8, jue: 7, vie: 6 },
  { hour: "4pm", lun: 7, mar: 9, mie: 8, jue: 8, vie: 6 },
  { hour: "5pm", lun: 7, mar: 8, mie: 8, jue: 7, vie: 5 },
  { hour: "6pm", lun: 5, mar: 7, mie: 7, jue: 6, vie: 5 },
  { hour: "7pm", lun: 4, mar: 5, mie: 6, jue: 5, vie: 4 },
  { hour: "8pm", lun: 3, mar: 4, mie: 4, jue: 4, vie: 3 },
  { hour: "9pm", lun: 2, mar: 3, mie: 3, jue: 3, vie: 2 },
];

const marketGrowth = [
  { year: "2021", value: 9.2 },
  { year: "2022", value: 10.1 },
  { year: "2023", value: 11.1 },
  { year: "2024", value: 12.0 },
  { year: "2025", value: 12.88 },
  { year: "2026", value: 13.7 },
  { year: "2027", value: 14.6 },
  { year: "2028", value: 15.5 },
  { year: "2029", value: 16.4 },
  { year: "2030", value: 17.38 },
];

const hashtagTiers = [
  {
    tier: "Tier 1 — Core",
    color: "#1B4332",
    tags: ["#adaptogenos", "#adaptogens", "#hongos", "#fungi", "#reishi", "#micelio"],
    desc: "Alta relevancia, uso directo. Audiencia de nicho con alta intención.",
  },
  {
    tier: "Tier 2 — Comunidad",
    color: "#40916C",
    tags: ["#salud", "#bienestar", "#saludybienestar", "#saludable", "#vidasana", "#medicinaintegrativa"],
    desc: "Conectan con la audiencia de bienestar general. Alto volumen.",
  },
  {
    tier: "Tier 3 — Ingredientes",
    color: "#D4A017",
    tags: ["#ashwagandha", "#lionsmane", "#cordyceps", "#chaga", "#ginseng", "#hongosmedicinales"],
    desc: "Hashtags de nicho por ingrediente específico.",
  },
  {
    tier: "Tier 4 — Beneficios",
    color: "#8B5E3C",
    tags: ["#antiestres", "#claridadmental", "#nootropicos", "#energia", "#superalimentos", "#sistemainmune"],
    desc: "Orientados al resultado emocional y funcional del consumidor.",
  },
  {
    tier: "Tier 5 — Amplificación",
    color: "#C8A96E",
    tags: ["#yoga", "#healthyfood", "#healthylifestyle", "#natural", "#plantbased"],
    desc: "Mega-tendencias para insertar el contenido en conversaciones más amplias.",
  },
];

const radarData = [
  { subject: "Autenticidad", UGC: 9, Profesional: 5, Híbrido: 7 },
  { subject: "Conversión", UGC: 7, Profesional: 9, Híbrido: 8 },
  { subject: "Alcance", UGC: 8, Profesional: 7, Híbrido: 9 },
  { subject: "Costo", UGC: 9, Profesional: 4, Híbrido: 6 },
  { subject: "Retención", UGC: 8, Profesional: 6, Híbrido: 8 },
  { subject: "Confianza", UGC: 9, Profesional: 7, Híbrido: 8 },
];

const topBrands = [
  { brand: "RYZE Superfoods", focus: "Café con hongos", format: "Video UGC", prop: "Energía sostenida + salud digestiva", duration: "90+ días" },
  { brand: "Superlativa Botanicals", focus: "Anti-estrés", format: "Video narrativo", prop: "Reducción de cortisol", duration: "90+ días" },
  { brand: "Viani Nutrition", focus: "Salud mental", format: "Imagen + texto", prop: "Claridad mental y sueño", duration: "60-90 días" },
  { brand: "Ereboost", focus: "Rendimiento", format: "Video influencer", prop: "Ingredientes naturales", duration: "90+ días" },
  { brand: "New Pharma", focus: "Hongos funcionales", format: "Imagen de producto", prop: "3 hongos en 1 fórmula", duration: "60+ días" },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); observer.disconnect(); } },
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return { ref, visible };
}

function RevealSection({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const { ref, visible } = useReveal();
  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delay}ms` }}
      className={`transition-all duration-700 ease-out ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}
    >
      {children}
    </div>
  );
}

function CountUp({ end, suffix = "", duration = 2000 }: { end: number; suffix?: string; duration?: number }) {
  const [count, setCount] = useState(0);
  const { ref, visible } = useReveal();
  useEffect(() => {
    if (!visible) return;
    const start = Date.now();
    const timer = setInterval(() => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * end));
      if (progress >= 1) clearInterval(timer);
    }, 16);
    return () => clearInterval(timer);
  }, [visible, end, duration]);
  return <span ref={ref}>{count}{suffix}</span>;
}

const HERO_URL = "https://private-us-east-1.manuscdn.com/sessionFile/o5HwFXgwRZlXUnnVbaLwdY/sandbox/9WkioGoaoKjXzvYQG1K6By-img-1_1772035050000_na1fn_YWRhcHRvZ2Vub3MtaGVybw.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvbzVId0ZYZ3dSWmxYVW5uVmJhTHdkWS9zYW5kYm94LzlXa2lvR29hb0tqWHp2WVFHMUs2QnktaW1nLTFfMTc3MjAzNTA1MDAwMF9uYTFmbl9ZV1JoY0hSdloyVnViM010YUdWeWJ3LnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=e86ll30enSXMedHm01aldpl4UGHB0mByuZEybe9PMxcQEkZljDjiFWuSHn8bDmXr-AG6AlMwv~MRFiDOIBheFEiLjhbHkqBfvR0ohrC0vHOVFrLR0i5ub5uqxcR3IqxvWQ6AnY5rKI-IxsAgU6baK26Ev9vESX-91D7udqGud3miDVagtE47whlpgHpmtdXk~b~CjDP8ZmN5zxwvBxvFqNO1QQZsW5GJR9PgNFT1d0UusfvPWVj53ovdpuHv9WAU7HW0OB2Z3jgXdoJE9d4JiCJvR~TVi~TlTyypzp4wbcuDAGzPoC0umbJ0VexRPgY~TM8Hxle-pzGaSPgiG3UAVA__";
const PATTERN_URL = "https://private-us-east-1.manuscdn.com/sessionFile/o5HwFXgwRZlXUnnVbaLwdY/sandbox/9WkioGoaoKjXzvYQG1K6By-img-2_1772035051000_na1fn_YWRhcHRvZ2Vub3MtcGF0dGVybg.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvbzVId0ZYZ3dSWmxYVW5uVmJhTHdkWS9zYW5kYm94LzlXa2lvR29hb0tqWHp2WVFHMUs2QnktaW1nLTJfMTc3MjAzNTA1MTAwMF9uYTFmbl9ZV1JoY0hSdloyVnViM010Y0dGMGRHVnliZy5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=lRpY~J4jRLBvE234ze1ENN-4fB-JzAtbIOYP5xnmC~P2LcdukCW3FHGA8V8LDGrl4CoszIdZc5iTcPUfnrUNAlEs7RdnZuaEKW9CY8Alx0M-xO91Eod-cQ7hE0fRaop6gkADE7z4Fib6p9A~4dfD9iQLMqUGSQZtjlOtWHz1aGt80yb~8XFx0MekIkFj7es8jfyZF0~Y3ICiy0D2WvFdLDmecBrhkhE-Vx2B22XHWFXi7PD1MnaaI7EcHfGUillcI5Zizd2cpZcY4z~vRErNAZuLlw3ZAbQ3yhFKZpB9Gn~XZqt9QFmh0FFNuKQCtx6It5ljy7SDxTF4g5OkFy8eOA__";
const NETWORK_URL = "https://private-us-east-1.manuscdn.com/sessionFile/o5HwFXgwRZlXUnnVbaLwdY/sandbox/9WkioGoaoKjXzvYQG1K6By-img-3_1772035046000_na1fn_YWRhcHRvZ2Vub3MtbWV0YS1hbmFseXNpcw.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvbzVId0ZYZ3dSWmxYVW5uVmJhTHdkWS9zYW5kYm94LzlXa2lvR29hb0tqWHp2WVFHMUs2QnktaW1nLTNfMTc3MjAzNTA0NjAwMF9uYTFmbl9ZV1JoY0hSdloyVnViM010YldWMFlTMWhibUZzZVhOcGN3LnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=pd08BT6fTLeT8NmdThl3jiK42cio994spcRl6b94v1zW4PWfdmOszK3pPo-3EGzgImUYSIYKEwBnpRE7dOdCCpROmoXOo-~hG~i2fxjMlraynFWhA1JLpp1F~CirzaLvQrlM43WUUuUGnzm6HJUqqHFes6m8nN8IgRCmv2FHUxG-3OYPxw7RzQ-NrsI-9kISxDogAspRoWT-HJFURpBob7gCcCQW26exqHK9Baq5VoW78k9VyikBR2Yf4cfcWagYM4-o7KXYgx-PTXZb820aDM3JhtGdwZO~VH6PEEOmyyDJweDImFO9EHnW4apXv2~4tY-mj7bRMFT-LjukIQxiGQ__";

// ─── Custom Tooltip ───────────────────────────────────────────────────────────

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white border border-[#e8e0d0] rounded-lg p-3 shadow-lg text-sm">
        <p className="font-semibold text-[#1B4332] mb-1">{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} style={{ color: p.color || p.fill }}>
            {p.name}: <span className="font-mono font-medium">{typeof p.value === "number" ? p.value.toFixed(1) : p.value}{p.name?.includes("%") || p.dataKey === "value" ? "%" : ""}</span>
          </p>
        ))}
      </div>
    );
  }
  return null;
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function Home() {
  const [activeNav, setActiveNav] = useState("resumen");
  const [activeTab, setActiveTab] = useState("lun");

  const navItems = [
    { id: "resumen", label: "Resumen" },
    { id: "mercado", label: "Mercado" },
    { id: "contenido", label: "Contenido" },
    { id: "hashtags", label: "Hashtags" },
    { id: "engagement", label: "Engagement" },
    { id: "horarios", label: "Horarios" },
    { id: "estrategia", label: "Estrategia" },
  ];

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
      setActiveNav(id);
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const sections = navItems.map(n => document.getElementById(n.id));
      const scrollY = window.scrollY + 120;
      for (let i = sections.length - 1; i >= 0; i--) {
        const el = sections[i];
        if (el && el.offsetTop <= scrollY) {
          setActiveNav(navItems[i].id);
          break;
        }
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const tabData = postingHours.map(h => ({
    hour: h.hour,
    value: h[activeTab as keyof typeof h] as number,
  }));

  return (
    <div className="min-h-screen" style={{ background: "oklch(0.978 0.006 90)", fontFamily: "'DM Sans', sans-serif" }}>
      
      {/* ── Sticky Nav ── */}
      <nav className="sticky top-0 z-50 border-b" style={{ background: "oklch(0.99 0.003 90 / 0.95)", backdropFilter: "blur(12px)", borderColor: "oklch(0.86 0.015 80)" }}>
        <div className="container flex items-center justify-between py-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ background: "oklch(0.32 0.08 145)" }}>
              <span className="text-white text-xs">🌿</span>
            </div>
            <span className="text-xs font-medium tracking-widest uppercase" style={{ color: "oklch(0.52 0.02 70)", fontFamily: "'DM Mono', monospace" }}>
              Adaptógenos · Meta Ads
            </span>
          </div>
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className="px-3 py-1.5 rounded-md text-sm transition-all"
                style={{
                  background: activeNav === item.id ? "oklch(0.32 0.08 145)" : "transparent",
                  color: activeNav === item.id ? "white" : "oklch(0.35 0.025 70)",
                  fontWeight: activeNav === item.id ? 500 : 400,
                }}
              >
                {item.label}
              </button>
            ))}
          </div>
          <span className="text-xs" style={{ color: "oklch(0.52 0.02 70)", fontFamily: "'DM Mono', monospace" }}>
            Feb 2026
          </span>
        </div>
      </nav>

      {/* ── Hero ── */}
      <section id="resumen" className="relative overflow-hidden" style={{ minHeight: "90vh" }}>
        <div className="absolute inset-0">
          <img src={HERO_URL} alt="Adaptógenos" className="w-full h-full object-cover" style={{ opacity: 0.25 }} />
          <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, oklch(0.978 0.006 90) 40%, oklch(0.978 0.006 90 / 0.6) 100%)" }} />
        </div>
        <div className="relative container py-24 lg:py-32">
          <div className="max-w-4xl">
            <RevealSection>
              <p className="text-xs tracking-[0.25em] uppercase mb-6" style={{ color: "oklch(0.52 0.02 70)", fontFamily: "'DM Mono', monospace" }}>
                Informe de Estrategia de Contenido · 2026
              </p>
              <h1 className="mb-6 leading-none" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: "clamp(3rem, 7vw, 6rem)", fontWeight: 700, color: "oklch(0.18 0.015 60)" }}>
                Adaptógenos<br />
                <span style={{ color: "oklch(0.32 0.08 145)" }}>en Meta</span>
              </h1>
              <p className="text-lg mb-10 max-w-2xl leading-relaxed" style={{ color: "oklch(0.35 0.025 70)" }}>
                Análisis exhaustivo de más de 2,500 anuncios activos en Meta Ads Library. Hashtags, tasas de interacción, formatos de contenido y horarios pico para marcas de adaptógenos y bienestar.
              </p>
            </RevealSection>

            <RevealSection delay={200}>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
                {[
                  { label: "Anuncios Analizados", value: 2500, suffix: "+", sub: "Meta Ads Library" },
                  { label: "Mercado Global 2025", value: 12, suffix: ".88B USD", sub: "CAGR 6.1%" },
                  { label: "Marcas Identificadas", value: 10, suffix: "+", sub: "LATAM & Global" },
                  { label: "Hashtags Mapeados", value: 30, suffix: "+", sub: "5 niveles" },
                ].map((stat, i) => (
                  <div key={i} className="stat-card">
                    <div className="text-2xl font-bold mb-1" style={{ fontFamily: "'DM Mono', monospace", color: "oklch(0.32 0.08 145)" }}>
                      <CountUp end={stat.value} suffix={stat.suffix} />
                    </div>
                    <div className="text-sm font-medium mb-0.5" style={{ color: "oklch(0.18 0.015 60)" }}>{stat.label}</div>
                    <div className="text-xs" style={{ color: "oklch(0.52 0.02 70)" }}>{stat.sub}</div>
                  </div>
                ))}
              </div>
            </RevealSection>

            <RevealSection delay={400}>
              <div className="flex flex-wrap gap-3">
                {["UGC lidera con 32.6%", "Martes-Jueves 11am-6pm", "CTR 1.63% benchmark", "76.9% ads activos 90+ días"].map((tag, i) => (
                  <span key={i} className="px-3 py-1.5 rounded-full text-sm border" style={{ borderColor: "oklch(0.32 0.08 145 / 0.3)", color: "oklch(0.32 0.08 145)", background: "oklch(0.32 0.08 145 / 0.06)" }}>
                    {tag}
                  </span>
                ))}
              </div>
            </RevealSection>
          </div>
        </div>
      </section>

      {/* ── Mercado ── */}
      <section id="mercado" className="py-20 border-t" style={{ borderColor: "oklch(0.86 0.015 80)" }}>
        <div className="container">
          <RevealSection>
            <div className="flex items-center gap-4 mb-2">
              <span className="text-xs tracking-widest uppercase" style={{ fontFamily: "'DM Mono', monospace", color: "oklch(0.52 0.02 70)" }}>01</span>
              <div className="flex-1 h-px" style={{ background: "oklch(0.86 0.015 80)" }} />
            </div>
            <h2 className="text-4xl md:text-5xl mb-4" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "oklch(0.18 0.015 60)" }}>
              Panorama del Mercado
            </h2>
            <p className="text-base mb-12 max-w-2xl" style={{ color: "oklch(0.35 0.025 70)" }}>
              El mercado global de adaptógenos experimenta un crecimiento sostenido impulsado por la demanda de bienestar holístico, reducción del estrés y claridad mental.
            </p>
          </RevealSection>

          <div className="grid lg:grid-cols-3 gap-8 items-start">
            <RevealSection delay={100}>
              <div className="lg:col-span-2">
                <h3 className="text-lg font-semibold mb-4" style={{ color: "oklch(0.18 0.015 60)" }}>Crecimiento del Mercado Global (USD Billones)</h3>
                <ResponsiveContainer width="100%" height={320}>
                  <AreaChart data={marketGrowth} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="greenGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#1B4332" stopOpacity={0.15} />
                        <stop offset="95%" stopColor="#1B4332" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.86 0.015 80)" />
                    <XAxis dataKey="year" tick={{ fontSize: 12, fontFamily: "'DM Mono', monospace" }} />
                    <YAxis tick={{ fontSize: 12, fontFamily: "'DM Mono', monospace" }} tickFormatter={v => `$${v}B`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="value" name="Mercado (USD B)" stroke="#1B4332" strokeWidth={2.5} fill="url(#greenGrad)" dot={{ fill: "#1B4332", r: 4 }} activeDot={{ r: 6 }} />
                  </AreaChart>
                </ResponsiveContainer>
                <p className="text-xs mt-2" style={{ color: "oklch(0.52 0.02 70)", fontFamily: "'DM Mono', monospace" }}>
                  * Proyección 2026-2030 basada en CAGR del 6.1%
                </p>
              </div>
            </RevealSection>

            <RevealSection delay={200}>
              <div className="space-y-4">
                {[
                  { label: "Mercado Global 2025", value: "USD 12.88B", color: "#1B4332" },
                  { label: "Proyección 2030", value: "USD 17.38B", color: "#40916C" },
                  { label: "CAGR 2025-2030", value: "6.1%", color: "#D4A017" },
                  { label: "Hongos Adaptógenos 2024", value: "USD 14.32B", color: "#8B5E3C" },
                  { label: "Proyección Hongos 2032", value: "USD 32.06B", color: "#C8A96E" },
                  { label: "Tasa Recompra Suplementos", value: "48%", color: "#1B4332" },
                ].map((item, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-lg border" style={{ borderColor: "oklch(0.86 0.015 80)", background: "white" }}>
                    <span className="text-sm" style={{ color: "oklch(0.35 0.025 70)" }}>{item.label}</span>
                    <span className="font-bold text-sm" style={{ fontFamily: "'DM Mono', monospace", color: item.color }}>{item.value}</span>
                  </div>
                ))}
              </div>
            </RevealSection>
          </div>

          {/* Top Brands Table */}
          <RevealSection delay={300}>
            <div className="mt-16">
              <h3 className="text-2xl mb-6" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "oklch(0.18 0.015 60)" }}>
                Anunciantes Clave en Meta Ads Library
              </h3>
              <div className="overflow-x-auto rounded-xl border" style={{ borderColor: "oklch(0.86 0.015 80)" }}>
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ background: "oklch(0.32 0.08 145)", color: "white" }}>
                      <th className="px-4 py-3 text-left font-medium">Marca</th>
                      <th className="px-4 py-3 text-left font-medium">Enfoque</th>
                      <th className="px-4 py-3 text-left font-medium">Formato</th>
                      <th className="px-4 py-3 text-left font-medium">Propuesta de Valor</th>
                      <th className="px-4 py-3 text-left font-medium">Duración</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topBrands.map((b, i) => (
                      <tr key={i} className="border-t transition-colors hover:bg-green-50/30" style={{ borderColor: "oklch(0.86 0.015 80)" }}>
                        <td className="px-4 py-3 font-semibold" style={{ color: "oklch(0.32 0.08 145)" }}>{b.brand}</td>
                        <td className="px-4 py-3" style={{ color: "oklch(0.35 0.025 70)" }}>{b.focus}</td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-0.5 rounded text-xs" style={{ background: "oklch(0.32 0.08 145 / 0.1)", color: "oklch(0.32 0.08 145)" }}>{b.format}</span>
                        </td>
                        <td className="px-4 py-3" style={{ color: "oklch(0.35 0.025 70)" }}>{b.prop}</td>
                        <td className="px-4 py-3 font-mono text-xs" style={{ color: "oklch(0.52 0.02 70)" }}>{b.duration}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </RevealSection>
        </div>
      </section>

      {/* ── Contenido ── */}
      <section id="contenido" className="py-20 border-t" style={{ borderColor: "oklch(0.86 0.015 80)", background: "white" }}>
        <div className="container">
          <RevealSection>
            <div className="flex items-center gap-4 mb-2">
              <span className="text-xs tracking-widest uppercase" style={{ fontFamily: "'DM Mono', monospace", color: "oklch(0.52 0.02 70)" }}>02</span>
              <div className="flex-1 h-px" style={{ background: "oklch(0.86 0.015 80)" }} />
            </div>
            <h2 className="text-4xl md:text-5xl mb-4" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "oklch(0.18 0.015 60)" }}>
              Tipos de Contenido
            </h2>
            <p className="text-base mb-12 max-w-2xl" style={{ color: "oklch(0.35 0.025 70)" }}>
              Análisis de formatos y creatividades basado en 500 anuncios de suplementos de alto rendimiento en Meta.
            </p>
          </RevealSection>

          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            <RevealSection delay={100}>
              <h3 className="text-lg font-semibold mb-4" style={{ color: "oklch(0.18 0.015 60)" }}>Distribución de Formatos</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie data={contentFormats} cx="50%" cy="50%" innerRadius={70} outerRadius={120} paddingAngle={3} dataKey="value">
                    {contentFormats.map((entry, index) => (
                      <Cell key={index} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => [`${value}%`, "Participación"]} />
                  <Legend formatter={(value) => <span style={{ fontSize: 12, color: "oklch(0.35 0.025 70)" }}>{value}</span>} />
                </PieChart>
              </ResponsiveContainer>
            </RevealSection>

            <RevealSection delay={200}>
              <h3 className="text-lg font-semibold mb-4" style={{ color: "oklch(0.18 0.015 60)" }}>Subtipos de Contenido Más Efectivos</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={contentTypes} layout="vertical" margin={{ left: 20, right: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.86 0.015 80)" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 11, fontFamily: "'DM Mono', monospace" }} tickFormatter={v => `${v}%`} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={110} />
                  <Tooltip formatter={(v: number) => [`${v}%`, "Uso"]} />
                  <Bar dataKey="value" name="% de uso" radius={[0, 4, 4, 0]}>
                    {contentTypes.map((_, i) => (
                      <Cell key={i} fill={i === 0 ? "#1B4332" : i === 1 ? "#40916C" : i === 2 ? "#D4A017" : i === 3 ? "#8B5E3C" : "#C8A96E"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </RevealSection>
          </div>

          {/* Radar Chart */}
          <RevealSection delay={300}>
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl mb-4" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "oklch(0.18 0.015 60)" }}>
                  Comparativa de Formatos
                </h3>
                <p className="text-sm mb-6" style={{ color: "oklch(0.35 0.025 70)" }}>
                  El contenido UGC lidera en autenticidad y confianza, mientras que el contenido profesional domina en conversión directa. La estrategia híbrida ofrece el mejor equilibrio general.
                </p>
                <div className="space-y-3">
                  {[
                    { label: "UGC / Testimonial", color: "#1B4332", desc: "Mejor para TOFU/MOFU — genera confianza" },
                    { label: "Imagen Profesional", color: "#D4A017", desc: "Mejor para BOFU — maximiza conversión" },
                    { label: "Híbrido", color: "#8B5E3C", desc: "Mejor equilibrio general — versatilidad" },
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="w-3 h-3 rounded-full mt-1 flex-shrink-0" style={{ background: item.color }} />
                      <div>
                        <span className="font-medium text-sm" style={{ color: "oklch(0.18 0.015 60)" }}>{item.label}</span>
                        <p className="text-xs" style={{ color: "oklch(0.52 0.02 70)" }}>{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <ResponsiveContainer width="100%" height={320}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="oklch(0.86 0.015 80)" />
                  <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 10]} tick={{ fontSize: 10 }} />
                  <Radar name="UGC" dataKey="UGC" stroke="#1B4332" fill="#1B4332" fillOpacity={0.15} strokeWidth={2} />
                  <Radar name="Profesional" dataKey="Profesional" stroke="#D4A017" fill="#D4A017" fillOpacity={0.1} strokeWidth={2} />
                  <Radar name="Híbrido" dataKey="Híbrido" stroke="#8B5E3C" fill="#8B5E3C" fillOpacity={0.1} strokeWidth={2} />
                  <Legend />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </RevealSection>

          {/* Fórmula de copywriting */}
          <RevealSection delay={400}>
            <div className="mt-16 p-8 rounded-2xl border-l-4" style={{ background: "oklch(0.32 0.08 145 / 0.05)", borderLeftColor: "oklch(0.32 0.08 145)" }}>
              <h3 className="text-xl mb-4" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "oklch(0.18 0.015 60)" }}>
                Fórmula de Copywriting de Alto Rendimiento
              </h3>
              <div className="flex flex-wrap items-center gap-2 mb-4">
                {["Hook (0-3s)", "→", "Problema Relatable", "→", "Solución (Producto)", "→", "Beneficio/Resultado", "→", "CTA"].map((step, i) => (
                  <span key={i}>
                    {step === "→" ? (
                      <span style={{ color: "oklch(0.52 0.02 70)" }}>{step}</span>
                    ) : (
                      <span className="px-3 py-1 rounded-full text-sm font-medium" style={{ background: "oklch(0.32 0.08 145)", color: "white" }}>
                        {step}
                      </span>
                    )}
                  </span>
                ))}
              </div>
              <p className="text-sm" style={{ color: "oklch(0.35 0.025 70)" }}>
                El 71% de los anuncios de mayor duración incluye al menos un emoji. Los disparadores emocionales más efectivos son: <strong>transformar</strong>, <strong>confianza</strong> y <strong>fatiga</strong>. Evitar clichés como "te lo mereces" o "paz mental".
              </p>
            </div>
          </RevealSection>
        </div>
      </section>

      {/* ── Hashtags ── */}
      <section id="hashtags" className="py-20 border-t relative overflow-hidden" style={{ borderColor: "oklch(0.86 0.015 80)" }}>
        <div className="absolute inset-0 opacity-5">
          <img src={PATTERN_URL} alt="" className="w-full h-full object-cover" />
        </div>
        <div className="relative container">
          <RevealSection>
            <div className="flex items-center gap-4 mb-2">
              <span className="text-xs tracking-widest uppercase" style={{ fontFamily: "'DM Mono', monospace", color: "oklch(0.52 0.02 70)" }}>03</span>
              <div className="flex-1 h-px" style={{ background: "oklch(0.86 0.015 80)" }} />
            </div>
            <h2 className="text-4xl md:text-5xl mb-4" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "oklch(0.18 0.015 60)" }}>
              Estrategia de Hashtags
            </h2>
            <p className="text-base mb-12 max-w-2xl" style={{ color: "oklch(0.35 0.025 70)" }}>
              Sistema de hashtags por niveles para equilibrar alcance y relevancia en publicaciones orgánicas y pagadas.
            </p>
          </RevealSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {hashtagTiers.map((tier, i) => (
              <RevealSection key={i} delay={i * 100}>
                <div className="p-6 rounded-xl border h-full" style={{ borderColor: "oklch(0.86 0.015 80)", background: "white", borderTop: `3px solid ${tier.color}` }}>
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-3 h-3 rounded-full" style={{ background: tier.color }} />
                    <span className="text-xs font-semibold tracking-wider uppercase" style={{ color: tier.color, fontFamily: "'DM Mono', monospace" }}>
                      {tier.tier}
                    </span>
                  </div>
                  <p className="text-xs mb-4" style={{ color: "oklch(0.52 0.02 70)" }}>{tier.desc}</p>
                  <div className="flex flex-wrap gap-2">
                    {tier.tags.map((tag, j) => (
                      <span key={j} className="px-2 py-1 rounded-md text-xs font-medium transition-all hover:scale-105" style={{ background: `${tier.color}15`, color: tier.color, border: `1px solid ${tier.color}30` }}>
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </RevealSection>
            ))}
          </div>

          {/* Network image */}
          <RevealSection delay={500}>
            <div className="mt-12 rounded-2xl overflow-hidden border" style={{ borderColor: "oklch(0.86 0.015 80)" }}>
              <div className="relative">
                <img src={NETWORK_URL} alt="Red de hashtags y conexiones" className="w-full object-cover" style={{ maxHeight: 320 }} />
                <div className="absolute inset-0 flex items-end p-6" style={{ background: "linear-gradient(to top, oklch(0.18 0.015 60 / 0.7) 0%, transparent 60%)" }}>
                  <p className="text-white text-sm max-w-lg">
                    Los hashtags funcionan como nodos de una red: los de nicho generan alta intención, los de comunidad amplían el alcance, y los de tendencia insertan la marca en conversaciones masivas.
                  </p>
                </div>
              </div>
            </div>
          </RevealSection>
        </div>
      </section>

      {/* ── Engagement ── */}
      <section id="engagement" className="py-20 border-t" style={{ borderColor: "oklch(0.86 0.015 80)", background: "white" }}>
        <div className="container">
          <RevealSection>
            <div className="flex items-center gap-4 mb-2">
              <span className="text-xs tracking-widest uppercase" style={{ fontFamily: "'DM Mono', monospace", color: "oklch(0.52 0.02 70)" }}>04</span>
              <div className="flex-1 h-px" style={{ background: "oklch(0.86 0.015 80)" }} />
            </div>
            <h2 className="text-4xl md:text-5xl mb-4" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "oklch(0.18 0.015 60)" }}>
              Tasas de Interacción
            </h2>
            <p className="text-base mb-12 max-w-2xl" style={{ color: "oklch(0.35 0.025 70)" }}>
              Benchmarks de la industria de salud y bienestar en Meta. Comparativa entre el promedio del sector y los top performers.
            </p>
          </RevealSection>

          <div className="grid lg:grid-cols-3 gap-8">
            <RevealSection delay={100}>
              <div className="lg:col-span-2">
                <h3 className="text-lg font-semibold mb-4" style={{ color: "oklch(0.18 0.015 60)" }}>Benchmark vs. Top Performers (%)</h3>
                <ResponsiveContainer width="100%" height={320}>
                  <BarChart data={engagementData} margin={{ top: 10, right: 20, left: 0, bottom: 60 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.86 0.015 80)" />
                    <XAxis dataKey="metric" tick={{ fontSize: 10 }} angle={-25} textAnchor="end" interval={0} />
                    <YAxis tick={{ fontSize: 11, fontFamily: "'DM Mono', monospace" }} tickFormatter={v => `${v}%`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend verticalAlign="top" />
                    <Bar dataKey="benchmark" name="Benchmark Industria" fill="#C8A96E" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="topPerformers" name="Top Performers" fill="#1B4332" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </RevealSection>

            <RevealSection delay={200}>
              <div className="space-y-4">
                <h3 className="text-lg font-semibold mb-4" style={{ color: "oklch(0.18 0.015 60)" }}>Métricas Clave</h3>
                {[
                  { label: "CTR Promedio (Salud)", value: "1.63%", note: "Benchmark industria", color: "#C8A96E" },
                  { label: "CTR Top Performers", value: "2.5–4%", note: "Objetivo a alcanzar", color: "#1B4332" },
                  { label: "Engagement IG Wellness", value: "3.1%", note: "Promedio de sector", color: "#C8A96E" },
                  { label: "Micro-Influencers IG", value: "3.86%", note: "10K–100K seguidores", color: "#40916C" },
                  { label: "Ads activos 90+ días", value: "76.9%", note: "De los top performers", color: "#1B4332" },
                  { label: "Completion Rate Video", value: "90%", note: "Videos <24 segundos", color: "#D4A017" },
                ].map((item, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-lg border" style={{ borderColor: "oklch(0.86 0.015 80)" }}>
                    <div>
                      <div className="text-sm font-medium" style={{ color: "oklch(0.18 0.015 60)" }}>{item.label}</div>
                      <div className="text-xs" style={{ color: "oklch(0.52 0.02 70)" }}>{item.note}</div>
                    </div>
                    <span className="font-bold text-sm" style={{ fontFamily: "'DM Mono', monospace", color: item.color }}>{item.value}</span>
                  </div>
                ))}
              </div>
            </RevealSection>
          </div>
        </div>
      </section>

      {/* ── Horarios ── */}
      <section id="horarios" className="py-20 border-t" style={{ borderColor: "oklch(0.86 0.015 80)" }}>
        <div className="container">
          <RevealSection>
            <div className="flex items-center gap-4 mb-2">
              <span className="text-xs tracking-widest uppercase" style={{ fontFamily: "'DM Mono', monospace", color: "oklch(0.52 0.02 70)" }}>05</span>
              <div className="flex-1 h-px" style={{ background: "oklch(0.86 0.015 80)" }} />
            </div>
            <h2 className="text-4xl md:text-5xl mb-4" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "oklch(0.18 0.015 60)" }}>
              Horarios Pico de Publicación
            </h2>
            <p className="text-base mb-8 max-w-2xl" style={{ color: "oklch(0.35 0.025 70)" }}>
              La ventana óptima de publicación para contenido de salud y bienestar en Instagram. Selecciona el día para ver el detalle horario.
            </p>
          </RevealSection>

          <RevealSection delay={100}>
            <div className="flex gap-2 mb-8 flex-wrap">
              {[
                { key: "lun", label: "Lunes" },
                { key: "mar", label: "Martes" },
                { key: "mie", label: "Miércoles" },
                { key: "jue", label: "Jueves" },
                { key: "vie", label: "Viernes" },
              ].map(day => (
                <button
                  key={day.key}
                  onClick={() => setActiveTab(day.key)}
                  className="px-4 py-2 rounded-lg text-sm font-medium transition-all"
                  style={{
                    background: activeTab === day.key ? "oklch(0.32 0.08 145)" : "white",
                    color: activeTab === day.key ? "white" : "oklch(0.35 0.025 70)",
                    border: `1px solid ${activeTab === day.key ? "oklch(0.32 0.08 145)" : "oklch(0.86 0.015 80)"}`,
                  }}
                >
                  {day.label}
                  {(day.key === "mar" || day.key === "mie") && (
                    <span className="ml-1 text-xs" style={{ color: activeTab === day.key ? "oklch(0.72 0.12 75)" : "oklch(0.72 0.12 75)" }}>★</span>
                  )}
                </button>
              ))}
              <span className="text-xs self-center" style={{ color: "oklch(0.52 0.02 70)" }}>★ Mejor día</span>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={tabData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.86 0.015 80)" />
                    <XAxis dataKey="hour" tick={{ fontSize: 11, fontFamily: "'DM Mono', monospace" }} />
                    <YAxis tick={{ fontSize: 11 }} domain={[0, 10]} tickFormatter={v => `${v}/10`} />
                    <Tooltip formatter={(v: number) => [`${v}/10`, "Nivel de engagement"]} />
                    <Bar dataKey="value" name="Engagement" radius={[4, 4, 0, 0]}>
                      {tabData.map((entry, i) => (
                        <Cell key={i} fill={entry.value >= 8 ? "#1B4332" : entry.value >= 6 ? "#40916C" : entry.value >= 4 ? "#C8A96E" : "#e8e0d0"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
                <div className="flex gap-4 mt-3 text-xs" style={{ color: "oklch(0.52 0.02 70)" }}>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm inline-block" style={{ background: "#1B4332" }} /> Óptimo (8-10)</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm inline-block" style={{ background: "#40916C" }} /> Bueno (6-7)</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm inline-block" style={{ background: "#C8A96E" }} /> Moderado (4-5)</span>
                </div>
              </div>

              <div className="space-y-4">
                <div className="p-5 rounded-xl border" style={{ borderColor: "oklch(0.86 0.015 80)", background: "white" }}>
                  <h4 className="font-semibold mb-3 text-sm" style={{ color: "oklch(0.18 0.015 60)" }}>Ventana Óptima Global</h4>
                  <div className="text-3xl font-bold mb-1" style={{ fontFamily: "'Cormorant Garamond', serif", color: "oklch(0.32 0.08 145)" }}>
                    11am – 6pm
                  </div>
                  <div className="text-sm" style={{ color: "oklch(0.52 0.02 70)" }}>Martes a Jueves</div>
                </div>
                <div className="p-5 rounded-xl border" style={{ borderColor: "oklch(0.86 0.015 80)", background: "white" }}>
                  <h4 className="font-semibold mb-3 text-sm" style={{ color: "oklch(0.18 0.015 60)" }}>Facebook (Salud)</h4>
                  <div className="space-y-2 text-sm" style={{ color: "oklch(0.35 0.025 70)" }}>
                    <div>🕘 <strong>9am – 11am</strong> (días de semana)</div>
                    <div>🕐 <strong>1pm – 2pm</strong> (días de semana)</div>
                    <div>🕙 <strong>10am – 12pm</strong> (fines de semana)</div>
                  </div>
                </div>
                <div className="p-5 rounded-xl border" style={{ borderColor: "oklch(0.86 0.015 80)", background: "oklch(0.32 0.08 145 / 0.05)" }}>
                  <h4 className="font-semibold mb-2 text-sm" style={{ color: "oklch(0.18 0.015 60)" }}>Regla de los 3 segundos</h4>
                  <p className="text-xs" style={{ color: "oklch(0.35 0.025 70)" }}>
                    Los videos deben tener un hook potente en los primeros 3 segundos. Los videos menores a 24 segundos logran un 90% de completion rate.
                  </p>
                </div>
              </div>
            </div>
          </RevealSection>
        </div>
      </section>

      {/* ── Estrategia ── */}
      <section id="estrategia" className="py-20 border-t" style={{ borderColor: "oklch(0.86 0.015 80)", background: "oklch(0.22 0.04 145)" }}>
        <div className="container">
          <RevealSection>
            <div className="flex items-center gap-4 mb-2">
              <span className="text-xs tracking-widest uppercase" style={{ fontFamily: "'DM Mono', monospace", color: "oklch(0.72 0.12 75)" }}>06</span>
              <div className="flex-1 h-px" style={{ background: "oklch(0.32 0.08 145)" }} />
            </div>
            <h2 className="text-4xl md:text-5xl mb-4" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "white" }}>
              Recomendaciones Estratégicas
            </h2>
            <p className="text-base mb-12 max-w-2xl" style={{ color: "oklch(0.75 0.02 90)" }}>
              Cinco pilares de acción para maximizar el rendimiento del contenido de adaptógenos en Meta durante 2026.
            </p>
          </RevealSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {[
              {
                num: "01",
                title: "Priorizar UGC",
                desc: "Construir una biblioteca de contenido generado por usuarios y micro-influencers. Enfocarse en demostraciones de producto auténticas y testimonios casuales para TOFU/MOFU.",
                tag: "Awareness",
                color: "#40916C",
              },
              {
                num: "02",
                title: "Creatividades Híbridas",
                desc: "Combinar la autenticidad del UGC con la claridad de imágenes profesionales. Desarrollar plantillas de video con testimonios + beneficios + CTA fuerte para BOFU.",
                tag: "Conversión",
                color: "#D4A017",
              },
              {
                num: "03",
                title: "Hashtags por Niveles",
                desc: "Usar 3-5 hashtags de cada tier en cada publicación. Equilibrar entre hashtags de nicho (alta intención) y de tendencia (alto alcance).",
                tag: "Alcance",
                color: "#C8A96E",
              },
              {
                num: "04",
                title: "Optimizar Horarios",
                desc: "Programar contenido clave para Martes y Miércoles entre 11am y 4pm. Monitorear analytics propios para ajustar según la audiencia específica.",
                tag: "Timing",
                color: "#8B5E3C",
              },
              {
                num: "05",
                title: "Vender Transformación",
                desc: "Articular claramente el problema que el producto resuelve y el resultado emocional/funcional que el cliente obtendrá. Usar la fórmula: Hook → Problema → Solución → Resultado → CTA.",
                tag: "Messaging",
                color: "#40916C",
              },
              {
                num: "06",
                title: "Campañas de Largo Plazo",
                desc: "El 76.9% de los anuncios de alto rendimiento estuvieron activos 90+ días. Mantener y optimizar las creatividades ganadoras en lugar de reemplazarlas frecuentemente.",
                tag: "Sostenibilidad",
                color: "#D4A017",
              },
            ].map((item, i) => (
              <RevealSection key={i} delay={i * 80}>
                <div className="p-6 rounded-xl h-full transition-all hover:-translate-y-1" style={{ background: "oklch(0.28 0.05 145)", border: "1px solid oklch(0.35 0.06 145)" }}>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold" style={{ fontFamily: "'DM Mono', monospace", color: item.color }}>{item.num}</span>
                    <span className="text-xs px-2 py-1 rounded-full" style={{ background: `${item.color}20`, color: item.color }}>{item.tag}</span>
                  </div>
                  <h3 className="text-lg font-semibold mb-2" style={{ fontFamily: "'Cormorant Garamond', serif", color: "white" }}>{item.title}</h3>
                  <p className="text-sm leading-relaxed" style={{ color: "oklch(0.75 0.02 90)" }}>{item.desc}</p>
                </div>
              </RevealSection>
            ))}
          </div>

          {/* Seasonal calendar */}
          <RevealSection delay={400}>
            <div className="p-8 rounded-2xl" style={{ background: "oklch(0.28 0.05 145)", border: "1px solid oklch(0.35 0.06 145)" }}>
              <h3 className="text-2xl mb-6" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "white" }}>
                Calendario Estacional de Contenido
              </h3>
              <div className="grid md:grid-cols-4 gap-4">
                {[
                  { q: "Q1", months: "Ene–Mar", theme: "Nuevo Año, Nuevo Yo", focus: "Resoluciones, bienestar, energía para el año", color: "#40916C" },
                  { q: "Q2", months: "Abr–Jun", theme: "Rutinas Establecidas", focus: "Mantenimiento, hábitos saludables, primavera", color: "#D4A017" },
                  { q: "Q3", months: "Jul–Sep", theme: "Energía de Verano", focus: "Rendimiento deportivo, viajes, actividad física", color: "#C8A96E" },
                  { q: "Q4", months: "Oct–Dic", theme: "Black Friday & Navidad", focus: "Mayor inversión publicitaria, ofertas, regalos", color: "#8B5E3C" },
                ].map((item, i) => (
                  <div key={i} className="p-4 rounded-xl" style={{ background: "oklch(0.22 0.04 145)", borderTop: `3px solid ${item.color}` }}>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-bold text-lg" style={{ fontFamily: "'DM Mono', monospace", color: item.color }}>{item.q}</span>
                      <span className="text-xs" style={{ color: "oklch(0.75 0.02 90)" }}>{item.months}</span>
                    </div>
                    <div className="font-semibold text-sm mb-1" style={{ color: "white" }}>{item.theme}</div>
                    <div className="text-xs" style={{ color: "oklch(0.65 0.02 90)" }}>{item.focus}</div>
                  </div>
                ))}
              </div>
            </div>
          </RevealSection>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="py-12 border-t" style={{ borderColor: "oklch(0.86 0.015 80)", background: "white" }}>
        <div className="container">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div>
              <h4 className="text-lg mb-1" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 700, color: "oklch(0.18 0.015 60)" }}>
                Informe de Estrategia de Contenido
              </h4>
              <p className="text-sm" style={{ color: "oklch(0.52 0.02 70)" }}>
                Adaptógenos en Meta Ads Library · Febrero 2026 · Generado por Manus AI
              </p>
            </div>
            <div className="text-xs" style={{ color: "oklch(0.52 0.02 70)", fontFamily: "'DM Mono', monospace" }}>
              <p>Fuentes: Meta Ads Library, Evolut Agency,</p>
              <p>Grand View Research, Sprout Social, Enrich Labs</p>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t text-xs" style={{ borderColor: "oklch(0.86 0.015 80)", color: "oklch(0.52 0.02 70)" }}>
            Los datos de engagement y benchmarks provienen de estudios de la industria y pueden variar según el mercado, audiencia y período. Se recomienda complementar con análisis propios de la cuenta.
          </div>
        </div>
      </footer>
    </div>
  );
}
