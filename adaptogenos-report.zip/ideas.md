# Ideas de Diseño: Informe de Estrategia de Contenido — Adaptógenos en Meta

## Contexto
Informe de investigación y estrategia de contenido sobre adaptógenos en Meta Ads Library. El contenido incluye gráficos interactivos, tablas de datos, análisis de hashtags, benchmarks de interacción y horarios pico de publicación.

---

<response>
<text>
## Idea 1: Botanical Dark Intelligence

**Design Movement:** Neo-Brutalism meets Dark Botanical — una fusión de datos densos con naturaleza orgánica

**Core Principles:**
1. Contraste extremo: fondos casi negros con acentos de verde musgo y ámbar dorado
2. Tipografía expresiva: títulos en serif pesado, datos en monospace
3. Datos como arte: los gráficos son elementos visuales primarios, no secundarios
4. Texturas orgánicas: patrones de hongos y raíces como elementos decorativos sutiles

**Color Philosophy:**
- Fondo: `#0D1117` (negro profundo, como tierra húmeda)
- Primario: `#4ADE80` (verde adaptógeno, vida)
- Acento: `#F59E0B` (ámbar dorado, energía)
- Texto: `#E2E8F0` (blanco suave)
- Muted: `#64748B`

**Layout Paradigm:**
Columnas asimétricas de 3-5 con "data cards" flotantes. La navegación es lateral (sidebar izquierdo fijo). El contenido fluye en un grid masonry con tarjetas de diferentes tamaños.

**Signature Elements:**
1. Líneas de datos animadas (sparklines) en los KPIs
2. Nodos de red para visualizar relaciones de hashtags
3. Fondo con textura sutil de micelio (SVG pattern)

**Interaction Philosophy:**
Hover revela capas de información adicional. Los gráficos se animan al entrar en el viewport. Tooltips ricos en datos.

**Animation:**
- Entrada: fade-in + slide-up con stagger de 100ms entre elementos
- Hover: escala sutil (1.02) + sombra verde
- Gráficos: animación de dibujo progresivo

**Typography System:**
- Display: `Playfair Display` (serif, autoridad científica)
- Body: `JetBrains Mono` para datos, `Inter` para texto narrativo
- Jerarquía: 48px display / 24px h2 / 16px body
</text>
<probability>0.08</probability>
</response>

<response>
<text>
## Idea 2: Wellness Report — Earthy Editorial

**Design Movement:** Editorial Magazine meets Scientific Report — inspirado en publicaciones como Kinfolk o Monocle pero para datos

**Core Principles:**
1. Espacio en blanco generoso como elemento de diseño activo
2. Tipografía editorial con jerarquía clara
3. Paleta terrosa y orgánica que evoca la naturaleza de los adaptógenos
4. Datos presentados con elegancia, no con densidad

**Color Philosophy:**
- Fondo: `#FAFAF7` (blanco cálido, papel de calidad)
- Primario: `#2D5016` (verde bosque profundo)
- Acento: `#8B5E3C` (tierra, raíces)
- Highlight: `#C8A96E` (dorado suave, ashwagandha)
- Texto: `#1A1A1A`

**Layout Paradigm:**
Layout de revista con columnas variables. Sección hero con texto grande y gráfico principal. Secciones alternadas entre texto-dominante y visual-dominante. Sin sidebar, navegación en top con scroll suave.

**Signature Elements:**
1. Separadores decorativos con iconografía de plantas/hongos (SVG)
2. Pull quotes con fondo de color terroso
3. Numeración de secciones en estilo editorial (01, 02, 03...)

**Interaction Philosophy:**
Scroll-driven: los elementos aparecen con animaciones suaves al hacer scroll. Los gráficos son interactivos pero discretos.

**Animation:**
- Scroll reveal: fade-in con translate-y de 20px
- Hover en tarjetas: underline animado en títulos
- Gráficos: transición suave de 800ms

**Typography System:**
- Display: `Cormorant Garamond` (serif elegante, 700 weight)
- Body: `Source Serif 4` para texto largo
- Data: `DM Mono` para números y métricas
- Jerarquía: 56px display / 32px h2 / 18px body
</text>
<probability>0.09</probability>
</response>

<response>
<text>
## Idea 3: Data-Forward Functional Dashboard

**Design Movement:** Swiss Grid meets Modern Data Journalism — precisión funcional con personalidad visual

**Core Principles:**
1. Los datos son el protagonista: cada elemento visual sirve a la información
2. Grid estricto con rupturas intencionales para crear tensión visual
3. Color como sistema semántico: cada color tiene un significado específico
4. Densidad informativa con respiración estratégica

**Color Philosophy:**
- Fondo: `#F8F6F1` (crema suave, calidez)
- Primario: `#1B4332` (verde oscuro, naturaleza)
- Secundario: `#40916C` (verde medio, crecimiento)
- Acento: `#D4A017` (amarillo ocre, energía/alerta)
- Destructivo/Negativo: `#9B2226` (rojo terroso)
- Texto: `#212121`

**Layout Paradigm:**
Dashboard de una sola página con secciones bien definidas. Navegación sticky con indicador de progreso. Cada sección tiene un "número de hallazgo" prominente. Grid de 12 columnas con cards de 3, 4 y 6 columnas.

**Signature Elements:**
1. KPI cards con sparklines animadas en la parte superior
2. Mapa de calor para horarios de publicación
3. Nube de hashtags interactiva con tamaños proporcionales al volumen

**Interaction Philosophy:**
Filtros interactivos que actualizan los gráficos en tiempo real. Tooltips detallados. Posibilidad de expandir secciones para ver más detalle.

**Animation:**
- Contadores animados para KPIs (count-up)
- Barras de gráficos que crecen desde cero
- Transición de 600ms con ease-out

**Typography System:**
- Display: `Syne` (geométrico, moderno, 800 weight)
- Body: `Nunito Sans` (legible, amigable)
- Data: `Space Mono` para métricas clave
- Jerarquía: 52px display / 28px h2 / 16px body
</text>
<probability>0.07</probability>
</response>

---

## Decisión de Diseño

**Enfoque elegido: Idea 2 — Wellness Report: Earthy Editorial**

Esta dirección equilibra la profundidad analítica del informe con una estética que resuena con el mundo de los adaptógenos y el bienestar. La paleta terrosa y orgánica crea una conexión visual con el tema, mientras que el layout editorial facilita la lectura de contenido denso. Los gráficos interactivos (Recharts) se integran de forma elegante sin dominar la experiencia.

**Adaptaciones para la implementación:**
- Usar `Cormorant Garamond` para títulos principales
- `DM Sans` para cuerpo de texto (más legible en pantalla que Source Serif)
- `DM Mono` para métricas y datos
- Paleta terrosa con verde bosque como color primario
- Gráficos con Recharts usando la paleta de colores del tema
